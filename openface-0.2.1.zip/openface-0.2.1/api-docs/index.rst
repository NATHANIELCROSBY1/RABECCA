OpenFace API Documentation
==========================

+ The code is available on GitHub at
  `cmusatyalab/openface <https://github.com/cmusatyalab/openface>`_
+ The main website is available at
  http://cmusatyalab.github.io/openface.

Contents:

.. toctree::
   :maxdepth: 2

   openface


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
